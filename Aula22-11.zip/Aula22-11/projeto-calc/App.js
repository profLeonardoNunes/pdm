import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  TouchableOpacity
} from 'react-native';
import styled from 'styled-components/native';

const Page = styled.View`
    background-color: #e2e2e2;
    flex:1;
`;
const Cabecalho = styled.View`
  background-color: #222;
  flex:1;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
const Titulo = styled.Text`
  color: #e2e2e2;
  font-size: 30;
  font-weight: bold;
`;
const Conteudo = styled.View`
  flex:3;
  justify-content: center;
  align-items: center;
`;
const Rodape = styled.View`
    background-color: #222;
  flex:1;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
const DesenvolvidoPor = styled.Text`
  color: #e2e2e2; 
`;

const Input = styled.TextInput`
  border:1px solid #000;
  height: 40px;
  width: 200px;
  background-color: #fff;
`;

const Operacoes = styled.View`
  flex-direction: row;  
`;
const Resultado = styled.Text`
  margin-top: 20px;
  font-weight: bold;
  font-size: 20;
`;
const Botao = styled.TouchableOpacity`    
  color: #fff;
  background-color: ${props => props.cor};
  justify-content: center;
  align-items: center;
  width: 80;
  height: 80;
  margin-right: 5px;
  margin-top: 5px;
  margin-bottom: 5px;
  margin-left: 5px;
  font-size: 35;
  font-weight: bold;
`;



export default function App() {
  const [n1, setN1] = useState();
  const [n2, setN2] = useState();
  const [operacao, setOperacao] = useState();
  const [resultado, setResultado] = useState();
  const [exibir, setExibir] = useState(false);

  function handleClick() {
    setExibir(true);
    if (operacao === "+") {
      setResultado(parseInt(n1) + parseInt(n2));
    }
    else if (operacao === "-") {
      setResultado(parseInt(n1) - parseInt(n2));
    }
    else if (operacao === "/") {
      setResultado(parseInt(n1) / parseInt(n2));
    }
    else if (operacao === "*") {
      setResultado(parseInt(n1) * parseInt(n2));
    }
  }

  return (
    <Page>
      <Cabecalho>
        <Titulo>Meu primeiro aplicativo</Titulo>
      </Cabecalho>
      <Conteudo>
        <Input onChangeText={e => setN1(e)}></Input>
        <Operacoes>
          <Botao onPress={e => setOperacao('+')} cor="red">+</Botao>
          <Botao onPress={e => setOperacao('-')} cor="green">-</Botao>
          <Botao onPress={e => setOperacao('/')} cor="blue">/</Botao>
          <Botao onPress={e => setOperacao('*')} cor="orange">*</Botao>

        </Operacoes>
        <Input onChangeText={e => setN2(e)}></Input>
        <Button title="Calcular" onPress={handleClick}></Button>

        {exibir &&
          <Resultado>{n1} {operacao} {n2} = {resultado}</Resultado>
        }
      </Conteudo>
      <Rodape>
        <DesenvolvidoPor>
          Desenvolvido por: Leonardo Nunes
        </DesenvolvidoPor>
      </Rodape>
    </Page >
  );
}

/*
Iniciando um projeto Expo
expo init NOME-DO-PROJETO
cd PASTA-CRIADA
expo-start ou npm-start
*/